1. Review each command below and write down what the command does:

    1. `pwd`
    2. `cd Desktop`
    3. `cd ~`
    4. `cd`
    5. `echo`
    6. `echo Hi there > greetings.txt`
    7. `cat greetings.txt`
    8. `mkdir /var/website`
    9. `!!`


2. Explain the difference between `cat`, `more`, and `less`. Use the `man` command to explore the `more` and `less` commands. When would you use one command over another?
3. Explain the difference between using `touch` and `echo >` to create a new text document.

