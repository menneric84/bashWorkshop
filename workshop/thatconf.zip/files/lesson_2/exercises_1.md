Try this little exercise to make sure you're comfortable navigating around using the double-dot syntax:

1. Use `cd` to go to your home folder.
2. Use `cd ../../var` to go to the `/var` folder.
3. Use `cd ../usr` to get to the `/usr folder`.
3. Use `cd local` to get to the `/usr/local` folder`.
4. Use `cd ../bin` to get to the `/usr/bin` folder.
5. Return to your home folder with `cd`.
