Try these exercises to see how much you remember:


1. Navigate to your home directory.
2. Use the `ls` command to list the contents of the `/var/log` directory.
3. In a single command, switch to the `/usr/local/bin` folder.
4. Switch to the `/var/log` folder in a single command using the double-dot syntax.
5. Switch to your home directory in a single command using the double-dot syntax.
6. Use the `pushd` command to navigate to `/opt`. Use `pushd` again to navigate to `/var/log`. Then use `popd` to return to your home directory.
