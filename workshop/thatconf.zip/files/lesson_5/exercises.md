Try these exercises to ensure you're comfortable automating things.

* Create a local `bin` folder in your home directory and add it to your path by modifying the `PATH` variable. Be sure to add the existing `PATH` value to your new directory.
* Modify your website creation script to create an optional default CSS file.
* Modify your website creation script to accept a value for the site's name and inject it into the `<title>` tag of the template.
* Use the `date` command to embed a copyright date in the footer of the site's template.
