This is *very* important text with *very* important words.

* These words are not important.
* Neither are these.

You can *always* tell very important text because it's in italics
